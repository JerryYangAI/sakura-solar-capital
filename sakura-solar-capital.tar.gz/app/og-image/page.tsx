import OGImage from '../../components/OGImage'

export default function OGImagePage() {
  return (
    <div className="w-[1200px] h-[630px]">
      <OGImage />
    </div>
  )
}


